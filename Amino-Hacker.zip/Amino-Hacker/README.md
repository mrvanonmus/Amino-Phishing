# Black-Water
<p>Make custom phishing page with Black-Water you just need to put required in create folder.</p>

<h3>Installation:-<h3>
  
  $ git clone https://github.com/kinghacker0/Black-Water.git
  
  $ cd Black-Water
  
  $ bash black-water.sh
  
  Now put your file and select your options.

<p>Watch Video Tutorial :-https://www.youtube.com/watch?v=QWvJn-yxOuM</p>
